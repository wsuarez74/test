# How to deploy a Python (Flask) web app to Azure App Service?

Video: https://youtu.be/ujiJaz2bRII?si=NlG15MmoWFpaB4ez 

This is the sample Flask application for the Azure Quickstart [Deploy a Python (Django or Flask) web app to Azure App Service](https://docs.microsoft.com/en-us/azure/app-service/quickstart-python). For instructions on how to create the Azure resources and deploy the application to Azure, refer to the Quickstart article.

